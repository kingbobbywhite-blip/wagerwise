import { americanToDecimal } from "./odds"
import type { Slip, SlipLeg } from "./types"

export interface LegDiff {
  status: "kept" | "swapped" | "removed" | "added"
  played?: SlipLeg
  suggested?: SlipLeg
}

export function diffLegs(suggested: SlipLeg[], played: SlipLeg[]): LegDiff[] {
  const out: LegDiff[] = []
  const playedByKey = new Map(played.map((p) => [keyOf(p), p]))
  const suggestedByKey = new Map(suggested.map((s) => [keyOf(s), s]))

  for (const s of suggested) {
    const match = playedByKey.get(keyOf(s))
    if (!match) {
      out.push({ status: "removed", suggested: s })
    } else if (match.pick !== s.pick) {
      out.push({ status: "swapped", suggested: s, played: match })
    } else {
      out.push({ status: "kept", suggested: s, played: match })
    }
  }
  for (const p of played) {
    if (!suggestedByKey.has(keyOf(p))) {
      out.push({ status: "added", played: p })
    }
  }
  return out
}

function keyOf(l: SlipLeg) {
  return `${l.player.toLowerCase()}|${l.market.toLowerCase()}|${Number(l.line)}`
}

/**
 * Realized P/L on a slip in dollars given a stake.
 * - WON: stake * (decimal - 1)
 * - LOST: -stake
 * - PUSH/VOID/PENDING: 0
 */
export function slipProfit(slip: Slip): number {
  if (!slip.stake || slip.payout_odds == null) {
    // Fall back to units_played * 1 unit if stake is unset
    if (slip.units_played != null && slip.payout_odds != null) {
      // we don't know unit_size here; assume $1 per unit for relative compare
      return profitFromStatus(slip.status, slip.units_played, slip.payout_odds)
    }
    return 0
  }
  return profitFromStatus(slip.status, Number(slip.stake), slip.payout_odds)
}

function profitFromStatus(status: Slip["status"], stake: number, payoutOdds: number): number {
  if (status === "WON") return stake * (americanToDecimal(payoutOdds) - 1)
  if (status === "LOST") return -stake
  return 0
}

/**
 * Hypothetical P/L of a SUGGESTED slip if it had been played with `stake` dollars.
 * We infer the suggestion result from its parent->child relationship: if the played child
 * has a status we use that for "did the legs hit?" — but ONLY if no legs were swapped/removed.
 * Otherwise we need the suggested slip's own settled legs.
 */
export function inferredSuggestedResult(suggested: Slip, suggestedLegs: SlipLeg[]): Slip["status"] {
  if (suggested.status !== "PENDING") return suggested.status
  if (suggestedLegs.length === 0) return "PENDING"
  if (suggestedLegs.some((l) => l.result === "PENDING")) return "PENDING"
  if (suggestedLegs.some((l) => l.result === "LOSS")) return "LOST"
  if (suggestedLegs.every((l) => l.result === "WIN" || l.result === "PUSH")) {
    return suggestedLegs.every((l) => l.result === "PUSH") ? "PUSH" : "WON"
  }
  return "PENDING"
}
