import { createClient } from "@/lib/supabase/server"
import type { Settings } from "./types"

const DEFAULT: Settings = {
  id: 1,
  bankroll: 1000,
  unit_size: 10,
  kelly_fraction: 0.25,
  updated_at: new Date(0).toISOString(),
}

export async function getSettings(): Promise<Settings> {
  const supabase = await createClient()
  const { data } = await supabase
    .from("settings")
    .select("id, bankroll, unit_size, kelly_fraction, updated_at")
    .eq("id", 1)
    .maybeSingle()
  if (!data) return DEFAULT
  return {
    id: 1,
    bankroll: Number(data.bankroll),
    unit_size: Number(data.unit_size),
    kelly_fraction: Number(data.kelly_fraction),
    updated_at: data.updated_at,
  }
}
