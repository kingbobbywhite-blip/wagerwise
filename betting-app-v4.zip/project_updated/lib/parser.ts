import type { Recommendation, Tier } from "./types"

/**
 * Flexible parser for WagerWise scraper output.
 * Accepts:
 *   - an array of prop objects
 *   - { props: [...] } / { data: [...] } / { results: [...] }
 *   - a single prop object
 * Each prop is normalized using a wide set of key aliases.
 */

export interface ParsedProp {
  player: string
  team: string | null
  opponent: string | null
  game_time: string | null
  market: string
  line: number
  over_odds: number | null
  under_odds: number | null
  projection: number | null
  edge_pct: number | null
  recommendation: Recommendation
  tier: Tier
  confidence: number
  raw: unknown
  // WagerWise scraper fields
  position: string | null
  hit_rate: string | null
  l5: string | null
  l10: string | null
  source: string | null
  scraped_at: string | null
}

const PLAYER_KEYS = ["player", "playerName", "player_name", "name", "athlete"]
const TEAM_KEYS = ["team", "teamAbbr", "team_abbr", "teamCode", "playerTeam"]
const OPP_KEYS = ["opponent", "opp", "vs", "versus", "opp_team"]
const TIME_KEYS = ["gameTime", "game_time", "startTime", "start_time", "commenceTime", "commence_time", "tipoff"]
const MARKET_KEYS = ["market", "propType", "prop_type", "stat", "statType", "stat_type", "category"]
const LINE_KEYS = ["line", "point", "points", "value", "total", "handicap", "spread"]
const OVER_KEYS = ["overOdds", "over_odds", "oddsOver", "odds_over", "over", "americanOver", "american_over"]
const UNDER_KEYS = ["underOdds", "under_odds", "oddsUnder", "odds_under", "under", "americanUnder", "american_under"]
const PROJ_KEYS = ["projection", "proj", "model", "forecast", "predicted", "expected", "model_value", "modelValue"]
// WagerWise scraper specific keys
const POSITION_KEYS = ["position", "pos"]
const HIT_RATE_KEYS = ["hitRate", "hit_rate", "hitrate"]
const L5_KEYS = ["L5", "l5", "last5", "last_5"]
const L10_KEYS = ["L10", "l10", "last10", "last_10"]
const SOURCE_KEYS = ["source", "sportsbook", "book"]
const SCRAPED_AT_KEYS = ["scrapedAt", "scraped_at", "timestamp", "fetchedAt"]

function pick<T = unknown>(obj: Record<string, unknown>, keys: string[]): T | undefined {
  for (const k of keys) {
    if (obj[k] != null && obj[k] !== "") return obj[k] as T
    // case-insensitive fallback
    const found = Object.keys(obj).find((ok) => ok.toLowerCase() === k.toLowerCase())
    if (found && obj[found] != null && obj[found] !== "") return obj[found] as T
  }
  return undefined
}

function toNum(v: unknown): number | null {
  if (v == null) return null
  if (typeof v === "number") return Number.isFinite(v) ? v : null
  if (typeof v === "string") {
    const cleaned = v.replace(/[+,$%]/g, "").trim()
    const n = Number.parseFloat(cleaned)
    return Number.isFinite(n) ? n : null
  }
  return null
}

function toAmerican(v: unknown): number | null {
  const n = toNum(v)
  if (n == null) return null
  // Some sources give decimal odds; auto-convert.
  if (n > 1 && n < 10) {
    if (n >= 2) return Math.round((n - 1) * 100)
    return Math.round(-100 / (n - 1))
  }
  return Math.round(n)
}

function classify(edgePct: number | null): { tier: Tier; rec: Recommendation; confidence: number } {
  if (edgePct == null) return { tier: "PASS", rec: "PASS", confidence: 0 }
  const abs = Math.abs(edgePct)
  // > 35% edge is almost always a parsing error or stale line — treat as PASS
  if (abs > 35) return { tier: "PASS", rec: "PASS", confidence: 0 }
  const rec: Recommendation = edgePct >= 0 ? "OVER" : "UNDER"
  let tier: Tier
  if (abs >= 12) tier = "LOCK"
  else if (abs >= 6) tier = "VALUE"
  else if (abs >= 3) tier = "RISKY"
  else tier = "PASS"
  const confidence = Math.min(95, Math.round(abs * 4))
  return { tier, rec, confidence }
}

/**
 * Converts any date string (including "5/3/2026" locale format) to a valid
 * ISO 8601 timestamp that PostgreSQL/Supabase accepts.
 * Returns null if the value is missing or unparseable.
 */
function toIsoTimestamp(v: unknown): string | null {
  if (v == null || v === "") return null
  const s = String(v).trim()
  // Already a valid ISO string (from new Date().toISOString())
  if (/^\d{4}-\d{2}-\d{2}T/.test(s)) return s
  // Locale date like "5/3/2026" or "5/3/2026, 7:11 PM"
  const d = new Date(s)
  if (!isNaN(d.getTime())) return d.toISOString()
  return null
}

function normalizeOne(raw: unknown): ParsedProp | null {
  if (!raw || typeof raw !== "object") return null
  const o = raw as Record<string, unknown>
  const player = pick<string>(o, PLAYER_KEYS)
  const market = pick<string>(o, MARKET_KEYS)
  const line = toNum(pick(o, LINE_KEYS))
  if (!player || !market || line == null) return null

  const projection = toNum(pick(o, PROJ_KEYS))
  const edgePct = projection != null && line !== 0 ? ((projection - line) / Math.abs(line)) * 100 : null
  const { tier, rec, confidence } = classify(edgePct)

  return {
    player: String(player).trim(),
    team: (pick<string>(o, TEAM_KEYS) as string) ?? null,
    opponent: (pick<string>(o, OPP_KEYS) as string) ?? null,
    game_time: (pick<string>(o, TIME_KEYS) as string) ?? null,
    market: String(market).trim(),
    line,
    over_odds: toAmerican(pick(o, OVER_KEYS)),
    under_odds: toAmerican(pick(o, UNDER_KEYS)),
    projection,
    edge_pct: edgePct != null ? Math.round(edgePct * 100) / 100 : null,
    recommendation: rec,
    tier,
    confidence,
    raw,
    // WagerWise scraper fields
    position: (pick<string>(o, POSITION_KEYS) as string) ?? null,
    hit_rate: (pick<string>(o, HIT_RATE_KEYS) as string) ?? null,
    l5: (pick<string>(o, L5_KEYS) as string) ?? null,
    l10: (pick<string>(o, L10_KEYS) as string) ?? null,
    source: (pick<string>(o, SOURCE_KEYS) as string) ?? null,
    scraped_at: toIsoTimestamp(pick<string>(o, SCRAPED_AT_KEYS)),
  }
}

export function parsePropsPayload(input: unknown): ParsedProp[] {
  let arr: unknown[] = []
  if (Array.isArray(input)) {
    arr = input
  } else if (input && typeof input === "object") {
    const o = input as Record<string, unknown>
    if (Array.isArray(o.props)) arr = o.props
    else if (Array.isArray(o.data)) arr = o.data
    else if (Array.isArray(o.results)) arr = o.results
    else if (Array.isArray(o.entries)) arr = o.entries
    else arr = [o]
  }
  const out: ParsedProp[] = []
  for (const item of arr) {
    const p = normalizeOne(item)
    if (p) out.push(p)
  }
  return out
}
