/**
 * American odds <-> implied probability and parlay math.
 */

export function americanToDecimal(american: number): number {
  if (american > 0) return 1 + american / 100
  return 1 + 100 / Math.abs(american)
}

export function decimalToAmerican(decimal: number): number {
  if (decimal >= 2) return Math.round((decimal - 1) * 100)
  return Math.round(-100 / (decimal - 1))
}

export function americanToImplied(american: number): number {
  if (american > 0) return 100 / (american + 100)
  return Math.abs(american) / (Math.abs(american) + 100)
}

export function parlayOdds(legs: number[]): number {
  if (legs.length === 0) return 0
  const decimal = legs.reduce((acc, a) => acc * americanToDecimal(a), 1)
  return decimalToAmerican(decimal)
}

export function formatAmerican(american: number | null | undefined): string {
  if (american == null || Number.isNaN(american)) return "--"
  return american > 0 ? `+${american}` : `${american}`
}

export function payoutFor(stake: number, american: number): number {
  return stake * (americanToDecimal(american) - 1)
}

/**
 * Kelly fraction for a single bet given:
 *   p  = your estimated win probability (0..1)
 *   b  = decimal odds - 1 (net win per $1 risked)
 * Returns the optimal fraction of bankroll to wager (can be negative; clamp to 0 in UI).
 *   f* = (b*p - (1 - p)) / b
 */
export function kelly(p: number, decimalOdds: number): number {
  const b = decimalOdds - 1
  if (b <= 0) return 0
  const f = (b * p - (1 - p)) / b
  return f
}

/**
 * Estimate "true" win probability for a parlay from per-leg edges.
 * For each leg we start with the book-implied probability, then nudge it by edge_pct
 * (treating edge_pct as a relative adjustment to the implied prob).
 * Caps each leg between 1% and 99% to avoid runaway numbers.
 */
export function estimateParlayWinProb(
  legs: { american: number; edgePct: number | null | undefined }[],
): number {
  if (legs.length === 0) return 0
  let p = 1
  for (const l of legs) {
    const implied = americanToImplied(l.american)
    const edge = (l.edgePct ?? 0) / 100
    // Apply edge as multiplicative bump; +20% edge means we believe true prob is implied * 1.20
    const adjusted = Math.max(0.01, Math.min(0.99, implied * (1 + edge)))
    p *= adjusted
  }
  return p
}

/**
 * Recommend stake (in dollars) using fractional Kelly.
 * Returns a stake clamped to >= 0 and <= bankroll * 0.1 (hard 10% cap to prevent ruin).
 */
export function recommendStake(args: {
  parlayAmericanOdds: number
  winProb: number
  bankroll: number
  kellyFraction: number
}): number {
  const decimal = americanToDecimal(args.parlayAmericanOdds)
  const f = kelly(args.winProb, decimal)
  if (f <= 0) return 0
  const fractional = f * args.kellyFraction
  const stake = args.bankroll * fractional
  const cap = args.bankroll * 0.1 // never more than 10% of roll on a single slip
  return Math.max(0, Math.min(stake, cap))
}
