import { estimateParlayWinProb, parlayOdds, recommendStake, americanToDecimal } from "./odds"
import type { Prop, Settings, SlipType } from "./types"

export interface SuggestedSlip {
  type: SlipType
  name: string
  legs: Prop[]
  payoutOdds: number
  rationale: string
  winProb: number
  recommendedStake: number
  recommendedUnits: number
}

// ---------------------------------------------------------------------------
// Market normalization
// ---------------------------------------------------------------------------
const MARKET_ALIASES: Record<string, string[]> = {
  Points:        ["points", "pts", "point", "scoring"],
  Rebounds:      ["rebounds", "reb", "rebound", "total rebounds"],
  Assists:       ["assists", "ast", "assist"],
  "3-Pointers":  ["3-pointers", "3pm", "threes", "three pointers", "3 pointers", "3 point", "3pts", "3-pt", "three point"],
  Steals:        ["steals", "stl", "steal"],
  Blocks:        ["blocks", "blk", "block", "blks"],
  Turnovers:     ["turnovers", "tov", "turnover"],
  Fouls:         ["fouls", "fls", "pf", "personal fouls", "foul"],
  "Pts+Reb+Ast": ["pra", "pts+reb+ast", "points+rebounds+assists", "p+r+a"],
  "Pts+Reb":     ["pts+reb", "points+rebounds", "p+r"],
  "Pts+Ast":     ["pts+ast", "points+assists", "p+a"],
  "Pass Yds":    ["passing yards", "pass yds", "pass yards", "passing yds"],
  "Rush Yds":    ["rushing yards", "rush yds", "rush yards", "rushing yds"],
  "Rec Yds":     ["receiving yards", "rec yds", "rec yards", "receiving yds"],
  Receptions:    ["receptions", "catches", "reception"],
  Touchdowns:    ["touchdowns", "tds", "td", "touchdown"],
  Hits:          ["hits", "hit"],
  "Home Runs":   ["home runs", "hr", "homers", "home run"],
  RBIs:          ["rbis", "rbi"],
  Strikeouts:    ["strikeouts", "k", "ks", "so"],
  Goals:         ["goals", "goal"],
  Saves:         ["saves", "goalie saves"],
  Shots:         ["shots", "shot", "shots on net", "shots on goal"],
}

export function normalizeMarket(market: string): string {
  if (!market) return "Unknown"
  const lower = market.toLowerCase().trim()
  for (const [canonical, aliases] of Object.entries(MARKET_ALIASES)) {
    if (aliases.some((a) => lower === a || lower.startsWith(a) || lower.includes(a))) {
      return canonical
    }
  }
  return market.split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ")
}

// ---------------------------------------------------------------------------
// Scoring
// ---------------------------------------------------------------------------

function parseRate(val: string | null | undefined): number | null {
  if (!val) return null
  const t = val.trim()
  if (t.includes("/")) {
    const parts = t.split("/")
    const n = parseFloat(parts[0].trim())
    const d = parseFloat(parts[1].trim())
    return isFinite(n) && isFinite(d) && d > 0 ? n / d : null
  }
  const n = parseFloat(t.replace(/[%]/g, "").trim())
  if (!isFinite(n)) return null
  return n > 1 ? n / 100 : n
}

/**
 * Composite high-probability score.
 * Weights: edge (2×) + confidence (0.5×) + hit_rate (20×) + L5 (15×) + L10 (10×) + tier bonus.
 */
function highProbScore(p: Prop): number {
  let score = Math.abs(p.edge_pct ?? 0) * 2 + (p.confidence ?? 0) * 0.5
  const hr = parseRate(p.hit_rate); if (hr != null) score += hr * 20
  const l5 = parseRate(p.l5);      if (l5 != null) score += l5 * 15
  const l10 = parseRate(p.l10);    if (l10 != null) score += l10 * 10
  if (p.tier === "LOCK")       score += 15
  else if (p.tier === "VALUE") score += 5
  return score
}

function oddsForPick(p: Prop): number {
  if (p.recommendation === "OVER")  return p.over_odds  ?? -110
  if (p.recommendation === "UNDER") return p.under_odds ?? -110
  return -110
}

export function oddsForRecommendation(p: Prop): number {
  return oddsForPick(p)
}

/** EV score: probability × payout — rewards likely winners that also pay well */
function evScore(p: Prop): number {
  return highProbScore(p) * americanToDecimal(oddsForPick(p))
}

// ---------------------------------------------------------------------------
// Step 1 — Deduplicate raw props
// Keep only the highest-scored prop per (player × normalizedMarket).
// ---------------------------------------------------------------------------
function dedupProps(props: Prop[]): Prop[] {
  const best = new Map<string, Prop>()
  for (const p of props) {
    const key = `${p.player.toLowerCase()}||${normalizeMarket(p.market)}`
    const existing = best.get(key)
    if (!existing || highProbScore(p) > highProbScore(existing)) {
      best.set(key, p)
    }
  }
  return Array.from(best.values())
}

// ---------------------------------------------------------------------------
// Step 2 — Build best-per-market pool
// Walk props sorted by a scoring fn, take the first (best) prop seen for
// each unique market. Result: one representative prop per stat type.
// Also enforces no duplicate players across the pool.
// ---------------------------------------------------------------------------
function buildBestPerMarketPool(props: Prop[], scoreFn: (p: Prop) => number): Prop[] {
  const sorted = [...props].sort((a, b) => scoreFn(b) - scoreFn(a))
  const pool: Prop[] = []
  const seenMarkets  = new Set<string>()
  const seenPlayers  = new Set<string>()

  for (const p of sorted) {
    const market    = normalizeMarket(p.market)
    const playerKey = p.player.toLowerCase()
    // Skip if we already have this market OR this player in the pool
    if (seenMarkets.has(market) || seenPlayers.has(playerKey)) continue
    pool.push(p)
    seenMarkets.add(market)
    seenPlayers.add(playerKey)
  }
  return pool // already sorted by scoreFn desc
}

// ---------------------------------------------------------------------------
// Step 3 — Pick legs from a pool, respecting used players
// ---------------------------------------------------------------------------
function pickLegs(pool: Prop[], maxLegs: number, usedPlayers: Set<string>): Prop[] {
  const legs: Prop[] = []
  for (const p of pool) {
    if (legs.length >= maxLegs) break
    const key = p.player.toLowerCase()
    if (usedPlayers.has(key)) continue
    legs.push(p)
    usedPlayers.add(key)
  }
  return legs
}

// ---------------------------------------------------------------------------
// Slip builder
// ---------------------------------------------------------------------------
function buildSlip(
  type: SlipType,
  name: string,
  legs: Prop[],
  rationale: string,
  settings: Settings,
): SuggestedSlip {
  const oddsList    = legs.map(oddsForPick)
  const payoutOdds  = parlayOdds(oddsList)
  const winProb     = estimateParlayWinProb(legs.map((l) => ({ american: oddsForPick(l), edgePct: l.edge_pct })))
  const recommendedStake = recommendStake({
    parlayAmericanOdds: payoutOdds,
    winProb,
    bankroll: settings.bankroll,
    kellyFraction: settings.kelly_fraction,
  })
  const recommendedUnits = settings.unit_size > 0 ? recommendedStake / settings.unit_size : 0
  return { type, name, legs, rationale, payoutOdds, winProb, recommendedStake, recommendedUnits }
}

function legSummary(legs: Prop[]): string {
  return legs.map((p) => `${p.player} (${normalizeMarket(p.market)})`).join(" · ")
}

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

/**
 * Generate 5 distinct cross-market parlays.
 *
 * Core guarantee: every leg in every parlay comes from a DIFFERENT stat market.
 * No player appears twice in the same slip.
 *
 * Algorithm:
 *   1. Dedup raw data (best prop per player×market)
 *   2. Build a best-per-market pool for each scoring strategy
 *      — one representative prop per unique stat type
 *   3. Pick legs from that pool (different order per strategy)
 *
 * Slips:
 *   1. Best Probability — top 4 markets by prob score
 *   2. Max EV           — top 4 markets by prob × payout
 *   3. Lock Floor       — top 3 LOCK markets + top 2 VALUE markets
 *   4. Value Surge      — top 4 VALUE-only markets by EV
 *   5. Power Parlay     — top 6 markets by prob score
 */
export function buildSuggestedSlips(props: Prop[], settings: Settings): SuggestedSlip[] {
  // Filter PASS-tier and RISKY (not confident enough for parlays)
  const usable = props.filter(
    (p) =>
      p.tier &&
      p.tier !== "PASS" &&
      p.tier !== "RISKY" &&
      p.recommendation &&
      p.recommendation !== "PASS",
  )

  if (usable.length === 0) return []

  // Dedup
  const clean = dedupProps(usable)

  // Build pools — one prop per market, sorted by each strategy
  const probPool = buildBestPerMarketPool(clean, highProbScore)
  const evPool   = buildBestPerMarketPool(clean, evScore)

  // LOCK-only and VALUE-only sub-pools (same market-diversity guarantee)
  const lockPool  = buildBestPerMarketPool(
    clean.filter((p) => p.tier === "LOCK"),
    highProbScore,
  )
  const valuePool = buildBestPerMarketPool(
    clean.filter((p) => p.tier === "VALUE"),
    evScore,
  )

  const slips: SuggestedSlip[] = []

  // ── 1. Best Probability ───────────────────────────────────────────────────
  {
    const used = new Set<string>()
    const legs = pickLegs(probPool, 4, used)
    if (legs.length >= 2) {
      slips.push(buildSlip(
        "SAFE",
        `Best Probability · ${legs.length}-leg`,
        legs,
        `Highest-probability leg from each of ${legs.length} stat markets — scored by edge + confidence + hit rate + L5/L10. | ${legSummary(legs)}`,
        settings,
      ))
    }
  }

  // ── 2. Max EV ─────────────────────────────────────────────────────────────
  {
    const used = new Set<string>()
    const legs = pickLegs(evPool, 4, used)
    if (legs.length >= 2) {
      slips.push(buildSlip(
        "VALUE",
        `Max EV · ${legs.length}-leg`,
        legs,
        `Best expected-value leg from each of ${legs.length} stat markets — prioritizes legs that are both likely AND pay well. | ${legSummary(legs)}`,
        settings,
      ))
    }
  }

  // ── 3. Lock Floor ─────────────────────────────────────────────────────────
  {
    const used      = new Set<string>()
    const lockLegs  = pickLegs(lockPool, 3, used)
    const valueLegs = pickLegs(valuePool, 2, used)
    const legs      = [...lockLegs, ...valueLegs]
    if (legs.length >= 3) {
      slips.push(buildSlip(
        "MIXED",
        `Lock Floor · ${legs.length}-leg`,
        legs,
        `${lockLegs.length} LOCK legs (high-confidence floor) + ${valueLegs.length} VALUE legs (payout boost) across ${legs.length} different stat markets. | ${legSummary(legs)}`,
        settings,
      ))
    }
  }

  // ── 4. Value Surge ────────────────────────────────────────────────────────
  {
    const used = new Set<string>()
    const legs = pickLegs(valuePool, 4, used)
    if (legs.length >= 2) {
      slips.push(buildSlip(
        "VALUE",
        `Value Surge · ${legs.length}-leg`,
        legs,
        `Best VALUE-tier leg from each of ${legs.length} stat markets — higher payout odds with strong positive edge. | ${legSummary(legs)}`,
        settings,
      ))
    }
  }

  // ── 5. Power Parlay ───────────────────────────────────────────────────────
  {
    const used = new Set<string>()
    const legs = pickLegs(probPool, 6, used)
    if (legs.length >= 4) {
      slips.push(buildSlip(
        "MIXED",
        `Power Parlay · ${legs.length}-leg`,
        legs,
        `One best leg from each of ${legs.length} stat markets — maximum market diversification for the high-payout slip. | ${legSummary(legs)}`,
        settings,
      ))
    }
  }

  return slips
}
