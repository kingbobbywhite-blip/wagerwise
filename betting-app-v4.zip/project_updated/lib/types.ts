export type League = "NBA" | "WNBA" | "NFL" | "NCAA"
export const LEAGUES: League[] = ["NBA", "WNBA", "NFL", "NCAA"]

export type Tier = "LOCK" | "VALUE" | "RISKY" | "PASS"
export type Recommendation = "OVER" | "UNDER" | "PASS"
export type Pick = "OVER" | "UNDER"
export type SlipType = "SAFE" | "VALUE" | "MIXED"
export type SlipKind = "SUGGESTED" | "PLAYED"
export type SlipStatus = "PENDING" | "WON" | "LOST" | "PUSH" | "VOID"
export type LegResult = "PENDING" | "WIN" | "LOSS" | "PUSH" | "VOID"

export interface Prop {
  id: string
  ingest_id: string | null
  league: string
  player: string
  team: string | null
  opponent: string | null
  game_time: string | null
  market: string
  line: number
  over_odds: number | null
  under_odds: number | null
  projection: number | null
  edge_pct: number | null
  recommendation: Recommendation | null
  tier: Tier | null
  confidence: number | null
  raw: unknown
  created_at: string
  // WagerWise scraper fields
  position: string | null
  hit_rate: string | null
  l5: string | null
  l10: string | null
  source: string | null
  scraped_at: string | null
}

export interface Slip {
  id: string
  name: string
  league: string | null
  slip_type: SlipType
  kind: SlipKind
  parent_slip_id: string | null
  payout_odds: number | null
  stake: number | null
  recommended_units: number | null
  units_played: number | null
  status: SlipStatus
  notes: string | null
  created_at: string
  settled_at: string | null
}

export interface SlipLeg {
  id: string
  slip_id: string
  prop_id: string | null
  player: string
  market: string
  line: number
  pick: Pick
  odds: number | null
  result: LegResult
  actual_value: number | null
  position: number
}

export interface Ingest {
  id: string
  league: string
  source: string
  prop_count: number
  notes: string | null
  created_at: string
  raw_json: unknown
}

export interface Settings {
  id: number
  bankroll: number
  unit_size: number
  kelly_fraction: number
  updated_at: string
}

export const SLIP_SELECT =
  "id, name, league, slip_type, kind, parent_slip_id, payout_odds, stake, recommended_units, units_played, status, notes, created_at, settled_at"
