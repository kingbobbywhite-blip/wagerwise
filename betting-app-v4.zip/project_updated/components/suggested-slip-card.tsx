"use client"

import { useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"
import { TierBadge } from "./tier-badge"
import { formatAmerican } from "@/lib/odds"
import { oddsForRecommendation } from "@/lib/slip-builder"
import type { Prop, SlipType } from "@/lib/types"
import { createSlip } from "@/app/slips/actions"
import { Bookmark, Play } from "lucide-react"
import { cn } from "@/lib/utils"

interface Props {
  type: SlipType
  name: string
  legs: Prop[]
  payoutOdds: number
  rationale: string
  league: string | null
  winProb: number
  recommendedStake: number
  recommendedUnits: number
  unitSize: number
}

const TONE: Record<SlipType, { ring: string; text: string; chip: string }> = {
  SAFE: { ring: "ring-primary/30", text: "text-primary", chip: "bg-primary/15 text-primary" },
  VALUE: { ring: "ring-accent/30", text: "text-accent", chip: "bg-accent/15 text-accent" },
  MIXED: { ring: "ring-border", text: "text-foreground", chip: "bg-secondary text-foreground" },
}

export function SuggestedSlipCard({
  type,
  name,
  legs,
  payoutOdds,
  rationale,
  league,
  winProb,
  recommendedStake,
  recommendedUnits,
  unitSize,
}: Props) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()

  function buildPayload(kind: "SUGGESTED" | "PLAYED") {
    return {
      name,
      league,
      slipType: type,
      kind,
      recommendedUnits,
      unitsPlayed: kind === "PLAYED" ? recommendedUnits : null,
      stake: kind === "PLAYED" ? recommendedStake : null,
      legs: legs.map((l) => ({
        prop_id: l.id,
        player: l.player,
        market: l.market,
        line: l.line,
        pick: (l.recommendation === "UNDER" ? "UNDER" : "OVER") as "OVER" | "UNDER",
        odds: oddsForRecommendation(l),
      })),
    }
  }

  function onTrack() {
    startTransition(async () => {
      const res = await createSlip(buildPayload("SUGGESTED"))
      if (!res.ok) toast.error(res.error)
      else toast.success("Suggestion tracked.")
    })
  }

  function onPlay() {
    startTransition(async () => {
      // First save the suggestion, then create a played child via the suggestion id.
      const sug = await createSlip(buildPayload("SUGGESTED"))
      if (!sug.ok) {
        toast.error(sug.error)
        return
      }
      const played = await createSlip({
        ...buildPayload("PLAYED"),
        parentSlipId: sug.slipId,
      })
      if (!played.ok) {
        toast.error(played.error)
        return
      }
      toast.success("Slip logged. Edit your actual play.")
      router.push(`/slips/${played.slipId}`)
    })
  }

  const tone = TONE[type]
  const tooLowConfidence = recommendedUnits <= 0

  return (
    <div className={cn("flex h-full flex-col rounded-lg border border-border/60 bg-card p-4 ring-1", tone.ring)}>
      <div className="flex items-center justify-between">
        <span
          className={cn(
            "rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em]",
            tone.chip,
          )}
        >
          {type}
        </span>
        <span className={cn("font-mono text-lg font-semibold tabular-nums", tone.text)}>
          {formatAmerican(payoutOdds)}
        </span>
      </div>
      <h3 className="mt-2 font-mono text-sm font-semibold tracking-tight">{name}</h3>
      <p className="mt-1 text-xs text-muted-foreground">{rationale}</p>

      <div className="mt-3 grid grid-cols-3 gap-2 rounded-md border border-border/40 bg-background/40 p-2">
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">Win prob</p>
          <p className="font-mono text-sm font-semibold tabular-nums">{(winProb * 100).toFixed(1)}%</p>
        </div>
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">Stake</p>
          <p className="font-mono text-sm font-semibold tabular-nums text-primary">
            {tooLowConfidence ? "PASS" : `$${recommendedStake.toFixed(0)}`}
          </p>
        </div>
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">Units</p>
          <p className="font-mono text-sm font-semibold tabular-nums">
            {tooLowConfidence ? "0u" : `${recommendedUnits.toFixed(2)}u`}
          </p>
        </div>
      </div>

      <ul className="mt-3 flex-1 space-y-1.5">
        {legs.map((p) => (
          <li
            key={p.id}
            className="flex items-center justify-between gap-2 rounded-md border border-border/40 bg-background/40 px-2.5 py-2"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <TierBadge tier={p.tier} />
                <span className="truncate text-xs font-medium">{p.player}</span>
              </div>
              <p className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">
                {p.market} · {p.line}
              </p>
            </div>
            <div className="flex flex-col items-end shrink-0">
              <span
                className={cn(
                  "font-mono text-[11px] font-semibold tracking-wider",
                  p.recommendation === "OVER" && "text-primary",
                  p.recommendation === "UNDER" && "text-destructive",
                )}
              >
                {p.recommendation}
              </span>
              <span className="font-mono text-[10px] tabular-nums text-muted-foreground">
                {formatAmerican(oddsForRecommendation(p))}
              </span>
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-4 flex flex-col gap-2">
        <Button
          onClick={onPlay}
          disabled={pending}
          className="w-full font-mono text-[11px] uppercase tracking-[0.18em]"
        >
          {pending ? <Spinner className="mr-2" /> : <Play className="mr-2 size-3.5" />}
          Log my play
        </Button>
        <Button
          onClick={onTrack}
          disabled={pending}
          variant="ghost"
          size="sm"
          className="w-full font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground"
        >
          <Bookmark className="mr-2 size-3 shrink-0" />
          Track suggestion only ({unitSize > 0 ? `1u = $${unitSize.toFixed(0)}` : "no unit"})
        </Button>
      </div>
    </div>
  )
}
