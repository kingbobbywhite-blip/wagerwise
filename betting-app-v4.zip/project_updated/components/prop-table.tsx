import { TierBadge } from "./tier-badge"
import { EdgeCell } from "./edge-cell"
import { formatAmerican } from "@/lib/odds"
import type { Prop } from "@/lib/types"
import { cn } from "@/lib/utils"

export function PropTable({ props, emptyLabel = "No props match." }: { props: Prop[]; emptyLabel?: string }) {
  if (props.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border/60 bg-card/40 p-8 text-center">
        <p className="font-mono text-xs uppercase tracking-[0.18em] text-muted-foreground">{emptyLabel}</p>
      </div>
    )
  }
  return (
    <div className="overflow-hidden rounded-lg border border-border/60 bg-card">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-secondary/40">
            <tr className="border-b border-border/60 text-left font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              <th className="px-3 py-2.5">Tier</th>
              <th className="px-3 py-2.5">Player</th>
              <th className="px-3 py-2.5">Matchup</th>
              <th className="px-3 py-2.5">Market</th>
              <th className="px-3 py-2.5 text-right">Line</th>
              <th className="px-3 py-2.5 text-right">Proj</th>
              <th className="px-3 py-2.5 text-right">Edge</th>
              <th className="px-3 py-2.5 text-right">Hit%</th>
              <th className="px-3 py-2.5 text-right">L5</th>
              <th className="px-3 py-2.5 text-right">L10</th>
              <th className="px-3 py-2.5 text-right">Pick</th>
              <th className="px-3 py-2.5 text-right">Odds</th>
              <th className="px-3 py-2.5 text-right">Conf</th>
            </tr>
          </thead>
          <tbody>
            {props.map((p) => {
              const pickOdds =
                p.recommendation === "OVER" ? p.over_odds : p.recommendation === "UNDER" ? p.under_odds : null
              return (
                <tr
                  key={p.id}
                  className="border-b border-border/40 last:border-0 hover:bg-secondary/30"
                >
                  <td className="px-3 py-2.5">
                    <TierBadge tier={p.tier} />
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex flex-col">
                      <span className="font-medium">{p.player}</span>
                      <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                        {p.league}{p.position ? ` · ${p.position}` : ""}
                      </span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 font-mono text-xs text-muted-foreground">
                    {p.team ?? "--"} {p.opponent ? `vs ${p.opponent}` : ""}
                  </td>
                  <td className="px-3 py-2.5 text-xs">{p.market}</td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums">{p.line}</td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {p.projection != null ? p.projection.toFixed(1) : "--"}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <EdgeCell edge={p.edge_pct} recommendation={p.recommendation} />
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {p.hit_rate ?? "--"}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {p.l5 ?? "--"}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {p.l10 ?? "--"}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <span
                      className={cn(
                        "font-mono text-[11px] font-semibold tracking-wider",
                        p.recommendation === "OVER" && "text-primary",
                        p.recommendation === "UNDER" && "text-destructive",
                        p.recommendation === "PASS" && "text-muted-foreground",
                      )}
                    >
                      {p.recommendation ?? "--"}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums">
                    {formatAmerican(pickOdds ?? null)}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {p.confidence != null ? `${Math.round(p.confidence)}` : "--"}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
