import { cn } from "@/lib/utils"
import type { Tier } from "@/lib/types"

const STYLES: Record<Tier, string> = {
  LOCK: "bg-primary/15 text-primary ring-primary/30",
  VALUE: "bg-accent/15 text-accent ring-accent/30",
  RISKY: "bg-muted text-muted-foreground ring-border",
  PASS: "bg-destructive/10 text-destructive ring-destructive/30",
}

export function TierBadge({ tier, className }: { tier: Tier | null | undefined; className?: string }) {
  const t: Tier = tier ?? "PASS"
  return (
    <span
      className={cn(
        "inline-flex items-center rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] ring-1",
        STYLES[t],
        className,
      )}
    >
      {t}
    </span>
  )
}
