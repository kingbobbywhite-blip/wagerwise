"use client"

import { useState, useTransition } from "react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Field, FieldDescription, FieldGroup, FieldLabel, FieldSet } from "@/components/ui/field"
import { Spinner } from "@/components/ui/spinner"
import { updateSettings } from "@/app/settings/actions"
import type { Settings } from "@/lib/types"

export function SettingsForm({ initial }: { initial: Settings }) {
  const [bankroll, setBankroll] = useState<string>(String(initial.bankroll))
  const [unit, setUnit] = useState<string>(String(initial.unit_size))
  const [kelly, setKelly] = useState<string>(String(initial.kelly_fraction))
  const [pending, start] = useTransition()

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    const b = Number(bankroll)
    const u = Number(unit)
    const k = Number(kelly)
    if (!Number.isFinite(b) || b <= 0) return toast.error("Bankroll must be a positive number.")
    if (!Number.isFinite(u) || u <= 0) return toast.error("Unit size must be a positive number.")
    if (!Number.isFinite(k) || k <= 0 || k > 1) return toast.error("Kelly fraction must be between 0 and 1.")
    start(async () => {
      const res = await updateSettings({ bankroll: b, unit_size: u, kelly_fraction: k })
      if (!res.ok) toast.error(res.error)
      else toast.success("Settings saved.")
    })
  }

  const unitsInRoll = Number(unit) > 0 ? Number(bankroll) / Number(unit) : 0

  return (
    <form onSubmit={onSubmit} className="rounded-lg border border-border/60 bg-card p-5">
      <FieldSet>
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="bankroll" className="font-mono text-[11px] uppercase tracking-[0.16em]">
              Bankroll ($)
            </FieldLabel>
            <Input
              id="bankroll"
              type="number"
              inputMode="decimal"
              step="0.01"
              min="0"
              value={bankroll}
              onChange={(e) => setBankroll(e.target.value)}
              className="font-mono"
            />
            <FieldDescription>Total money you&apos;re willing to risk across all slips.</FieldDescription>
          </Field>

          <Field>
            <FieldLabel htmlFor="unit" className="font-mono text-[11px] uppercase tracking-[0.16em]">
              Unit size ($)
            </FieldLabel>
            <Input
              id="unit"
              type="number"
              inputMode="decimal"
              step="0.01"
              min="0"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="font-mono"
            />
            <FieldDescription>
              {unitsInRoll > 0
                ? `${unitsInRoll.toFixed(0)} units in your bankroll. 1u = $${Number(unit).toFixed(2)}.`
                : "Pick a dollar value for one unit."}
            </FieldDescription>
          </Field>

          <Field>
            <FieldLabel htmlFor="kelly" className="font-mono text-[11px] uppercase tracking-[0.16em]">
              Kelly fraction (0-1)
            </FieldLabel>
            <Input
              id="kelly"
              type="number"
              inputMode="decimal"
              step="0.05"
              min="0"
              max="1"
              value={kelly}
              onChange={(e) => setKelly(e.target.value)}
              className="font-mono"
            />
            <FieldDescription>
              Fractional Kelly multiplier. 0.25 = quarter-Kelly (recommended for parlays — lower variance, less risk of ruin if your edge estimate is off).
            </FieldDescription>
          </Field>
        </FieldGroup>
      </FieldSet>

      <div className="mt-5 flex items-center justify-between">
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          Hard cap: 10% of bankroll per slip
        </p>
        <Button type="submit" disabled={pending} className="font-mono text-xs uppercase tracking-wider">
          {pending ? <Spinner className="mr-2" /> : null}
          Save settings
        </Button>
      </div>
    </form>
  )
}
