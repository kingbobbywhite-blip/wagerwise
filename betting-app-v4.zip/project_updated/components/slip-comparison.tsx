import Link from "next/link"
import { ArrowRight, Equal, Minus, Plus, Repeat } from "lucide-react"
import { diffLegs } from "@/lib/compare"
import { formatAmerican } from "@/lib/odds"
import type { Slip, SlipLeg } from "@/lib/types"
import { cn } from "@/lib/utils"

const STATUS_ICON: Record<string, { Icon: typeof Equal; tone: string; label: string }> = {
  kept: { Icon: Equal, tone: "text-muted-foreground", label: "Same" },
  swapped: { Icon: Repeat, tone: "text-accent", label: "Swapped" },
  removed: { Icon: Minus, tone: "text-destructive", label: "Removed" },
  added: { Icon: Plus, tone: "text-primary", label: "Added" },
}

export function SlipComparison({
  played,
  playedLegs,
  suggested,
  suggestedLegs,
}: {
  played: Slip
  playedLegs: SlipLeg[]
  suggested: Slip
  suggestedLegs: SlipLeg[]
}) {
  const diffs = diffLegs(suggestedLegs, playedLegs)
  const swappedCount = diffs.filter((d) => d.status === "swapped").length
  const removedCount = diffs.filter((d) => d.status === "removed").length
  const addedCount = diffs.filter((d) => d.status === "added").length
  const totalChanges = swappedCount + removedCount + addedCount
  const isIdentical = totalChanges === 0

  const oddsDelta =
    played.payout_odds != null && suggested.payout_odds != null
      ? played.payout_odds - suggested.payout_odds
      : null

  return (
    <section className="rounded-lg border border-border/60 bg-card">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 p-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Comparison · played vs suggested
          </p>
          <h2 className="mt-1 font-mono text-sm font-semibold tracking-tight">
            {isIdentical ? "Identical to suggestion" : `${totalChanges} deviation${totalChanges === 1 ? "" : "s"}`}
          </h2>
        </div>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-right">
          <Stat label="Suggested odds" value={formatAmerican(suggested.payout_odds)} />
          <Stat label="Played odds" value={formatAmerican(played.payout_odds)} />
          {oddsDelta != null ? (
            <Stat
              label="Δ odds"
              value={`${oddsDelta > 0 ? "+" : ""}${oddsDelta}`}
              tone={oddsDelta >= 0 ? "primary" : "destructive"}
            />
          ) : null}
          <Link
            href={`/slips/${suggested.id}`}
            className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
          >
            View suggestion →
          </Link>
        </div>
      </header>

      <ul className="divide-y divide-border/40">
        {diffs.map((d, idx) => {
          const meta = STATUS_ICON[d.status]
          const Icon = meta.Icon
          const ref = d.played ?? d.suggested!
          return (
            <li key={`${ref.id}-${idx}`} className="flex items-center gap-3 px-4 py-2.5">
              <span className={cn("flex size-6 items-center justify-center rounded-full bg-secondary/60", meta.tone)}>
                <Icon className="size-3.5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{ref.player}</p>
                <p className="font-mono text-[11px] text-muted-foreground">
                  {ref.market} · {Number(ref.line)}
                </p>
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px]">
                {d.status === "swapped" && d.suggested && d.played ? (
                  <>
                    <PickPill pick={d.suggested.pick} muted />
                    <ArrowRight className="size-3 text-muted-foreground" />
                    <PickPill pick={d.played.pick} />
                  </>
                ) : null}
                {d.status === "kept" && d.played ? <PickPill pick={d.played.pick} muted /> : null}
                {d.status === "removed" && d.suggested ? <PickPill pick={d.suggested.pick} muted strike /> : null}
                {d.status === "added" && d.played ? <PickPill pick={d.played.pick} /> : null}
                <span className={cn("min-w-[60px] text-right font-mono uppercase tracking-wider", meta.tone)}>
                  {meta.label}
                </span>
              </div>
            </li>
          )
        })}
      </ul>
    </section>
  )
}

function PickPill({ pick, muted = false, strike = false }: { pick: "OVER" | "UNDER"; muted?: boolean; strike?: boolean }) {
  return (
    <span
      className={cn(
        "rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider",
        pick === "OVER" ? "text-primary" : "text-destructive",
        muted && "opacity-60",
        strike && "line-through",
      )}
    >
      {pick}
    </span>
  )
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "primary" | "destructive" }) {
  return (
    <div>
      <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">{label}</p>
      <p
        className={cn(
          "font-mono text-sm font-semibold tabular-nums",
          tone === "primary" && "text-primary",
          tone === "destructive" && "text-destructive",
        )}
      >
        {value}
      </p>
    </div>
  )
}
