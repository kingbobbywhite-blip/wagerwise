import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  tone = "default",
}: {
  label: string
  value: string | number
  hint?: string
  icon?: LucideIcon
  tone?: "default" | "primary" | "accent" | "destructive"
}) {
  return (
    <div className="rounded-lg border border-border/60 bg-card p-4">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</span>
        {Icon ? (
          <Icon
            className={cn(
              "size-3.5",
              tone === "primary" && "text-primary",
              tone === "accent" && "text-accent",
              tone === "destructive" && "text-destructive",
              tone === "default" && "text-muted-foreground",
            )}
            aria-hidden
          />
        ) : null}
      </div>
      <div
        className={cn(
          "mt-2 font-mono text-2xl font-semibold tabular-nums",
          tone === "primary" && "text-primary",
          tone === "accent" && "text-accent",
          tone === "destructive" && "text-destructive",
        )}
      >
        {value}
      </div>
      {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  )
}
