"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Spinner } from "@/components/ui/spinner"
import { ButtonGroup } from "@/components/ui/button-group"
import { formatAmerican } from "@/lib/odds"
import type { LegResult, Slip, SlipLeg, SlipStatus } from "@/lib/types"
import {
  cloneSuggestedAsPlayed,
  deleteSlip,
  removeLeg,
  togglePick,
  updateLegResult,
  updateSlipStatus,
  updateSlipUnitsPlayed,
} from "@/app/slips/actions"
import { cn } from "@/lib/utils"
import { ArrowLeftRight, Play, Trash2, X } from "lucide-react"

const STATUSES: SlipStatus[] = ["PENDING", "WON", "LOST", "PUSH", "VOID"]
const RESULTS: LegResult[] = ["PENDING", "WIN", "LOSS", "PUSH", "VOID"]

export function SlipDetailControls({ slip, legs }: { slip: Slip; legs: SlipLeg[] }) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [unitsInput, setUnitsInput] = useState<string>(
    slip.units_played != null ? String(slip.units_played) : "",
  )

  const isPlayed = slip.kind === "PLAYED"
  const isSuggested = slip.kind === "SUGGESTED"

  function setStatus(s: SlipStatus) {
    startTransition(async () => {
      await updateSlipStatus(slip.id, s)
      toast.success(`Slip marked ${s}.`)
    })
  }

  function setLeg(legId: string, r: LegResult) {
    startTransition(async () => {
      await updateLegResult(legId, slip.id, r)
    })
  }

  function onTogglePick(legId: string, pick: SlipLeg["pick"]) {
    startTransition(async () => {
      await togglePick(legId, slip.id, pick)
      toast.success("Pick swapped. Payout odds recalculated.")
    })
  }

  function onRemove(legId: string) {
    if (!confirm("Remove this leg from the slip?")) return
    startTransition(async () => {
      await removeLeg(legId, slip.id)
      toast.success("Leg removed.")
    })
  }

  function onDelete() {
    if (!confirm("Delete this slip? This cannot be undone.")) return
    startTransition(async () => {
      await deleteSlip(slip.id)
      toast.success("Slip deleted.")
      router.push("/slips")
    })
  }

  function onClone() {
    startTransition(async () => {
      const res = await cloneSuggestedAsPlayed(slip.id)
      if (!res.ok) {
        toast.error(res.error)
        return
      }
      toast.success("Played slip created.")
      router.push(`/slips/${res.slipId}`)
    })
  }

  function onSaveUnits() {
    const n = unitsInput === "" ? null : Number(unitsInput)
    if (n != null && (!Number.isFinite(n) || n < 0)) return toast.error("Units must be 0 or greater.")
    startTransition(async () => {
      await updateSlipUnitsPlayed(slip.id, n)
      toast.success("Units played updated.")
    })
  }

  return (
    <div className="space-y-6">
      {isSuggested ? (
        <section className="flex flex-col gap-3 rounded-lg border border-primary/30 bg-primary/5 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">Suggestion</p>
            <p className="mt-0.5 text-sm">
              This is the model&apos;s untouched pick. Log what you actually played to compare against it.
            </p>
          </div>
          <Button onClick={onClone} disabled={pending} className="font-mono text-xs uppercase tracking-wider">
            {pending ? <Spinner className="mr-2" /> : <Play className="mr-2 size-3.5" />}
            Log my play
          </Button>
        </section>
      ) : null}

      {isPlayed && slip.parent_slip_id ? (
        <section className="rounded-lg border border-border/60 bg-card p-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Linked suggestion</p>
          <Link
            href={`/slips/${slip.parent_slip_id}`}
            className="mt-1 inline-flex items-center font-mono text-sm text-primary hover:underline"
          >
            View original suggestion →
          </Link>
        </section>
      ) : null}

      {isPlayed ? (
        <section className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-baseline justify-between">
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Units played</p>
            {slip.recommended_units != null ? (
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                Recommended: {Number(slip.recommended_units).toFixed(2)}u
              </p>
            ) : null}
          </div>
          <div className="mt-2 flex gap-2">
            <Input
              type="number"
              inputMode="decimal"
              step="0.1"
              min="0"
              value={unitsInput}
              onChange={(e) => setUnitsInput(e.target.value)}
              placeholder="0.0"
              className="font-mono"
            />
            <Button onClick={onSaveUnits} disabled={pending} variant="secondary" className="font-mono text-xs uppercase tracking-wider">
              Save
            </Button>
          </div>
        </section>
      ) : null}

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.16em]">Settle slip</h2>
          {pending ? <Spinner /> : null}
        </div>
        <ButtonGroup>
          {STATUSES.map((s) => (
            <Button
              key={s}
              type="button"
              variant={slip.status === s ? "default" : "outline"}
              onClick={() => setStatus(s)}
              className="font-mono text-[11px] uppercase tracking-wider"
            >
              {s}
            </Button>
          ))}
        </ButtonGroup>
      </section>

      <section>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.16em]">Legs</h2>
          {isPlayed ? (
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
              Tap pick to swap · Tap × to remove
            </p>
          ) : null}
        </div>
        <div className="overflow-hidden rounded-lg border border-border/60 bg-card">
          <table className="w-full text-sm">
            <thead className="bg-secondary/40">
              <tr className="border-b border-border/60 text-left font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                <th className="px-3 py-2.5">Player</th>
                <th className="px-3 py-2.5">Market</th>
                <th className="px-3 py-2.5 text-right">Line</th>
                <th className="px-3 py-2.5 text-right">Pick</th>
                <th className="px-3 py-2.5 text-right">Odds</th>
                <th className="px-3 py-2.5">Result</th>
                {isPlayed ? <th className="px-2 py-2.5" /> : null}
              </tr>
            </thead>
            <tbody>
              {legs.map((l) => (
                <tr key={l.id} className="border-b border-border/40 last:border-0">
                  <td className="px-3 py-2.5 font-medium">{l.player}</td>
                  <td className="px-3 py-2.5 text-xs">{l.market}</td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums">{Number(l.line)}</td>
                  <td className="px-3 py-2.5 text-right">
                    {isPlayed ? (
                      <button
                        type="button"
                        onClick={() => onTogglePick(l.id, l.pick)}
                        disabled={pending}
                        className={cn(
                          "inline-flex items-center gap-1 rounded px-1.5 py-0.5 font-mono text-[11px] font-semibold tracking-wider transition-colors",
                          l.pick === "OVER"
                            ? "text-primary hover:bg-primary/10"
                            : "text-destructive hover:bg-destructive/10",
                        )}
                      >
                        {l.pick}
                        <ArrowLeftRight className="size-3 opacity-60" />
                      </button>
                    ) : (
                      <span
                        className={cn(
                          "font-mono text-[11px] font-semibold tracking-wider",
                          l.pick === "OVER" ? "text-primary" : "text-destructive",
                        )}
                      >
                        {l.pick}
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums">
                    {formatAmerican(l.odds ?? null)}
                  </td>
                  <td className="px-3 py-2.5">
                    <ButtonGroup>
                      {RESULTS.map((r) => (
                        <Button
                          key={r}
                          type="button"
                          size="sm"
                          variant={l.result === r ? "default" : "outline"}
                          className={cn(
                            "h-7 font-mono text-[10px] uppercase tracking-wider",
                            l.result === r && r === "WIN" && "bg-primary text-primary-foreground hover:bg-primary/90",
                            l.result === r && r === "LOSS" && "bg-destructive text-destructive-foreground hover:bg-destructive/90",
                          )}
                          onClick={() => setLeg(l.id, r)}
                        >
                          {r}
                        </Button>
                      ))}
                    </ButtonGroup>
                  </td>
                  {isPlayed ? (
                    <td className="px-2 py-2.5 text-right">
                      <button
                        type="button"
                        onClick={() => onRemove(l.id)}
                        disabled={pending}
                        className="rounded p-1 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                        aria-label="Remove leg"
                      >
                        <X className="size-3.5" />
                      </button>
                    </td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="flex justify-end">
        <Button
          variant="ghost"
          size="sm"
          onClick={onDelete}
          className="font-mono text-[11px] uppercase tracking-wider text-destructive hover:bg-destructive/10 hover:text-destructive"
        >
          <Trash2 className="mr-1.5 size-3.5" />
          Delete slip
        </Button>
      </section>
    </div>
  )
}
