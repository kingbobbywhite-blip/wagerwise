"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { LEAGUES, type League } from "@/lib/types"
import { ingestProps } from "@/app/ingest/actions"
import { Upload } from "lucide-react"

export function IngestForm() {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [league, setLeague] = useState<League>("NBA")
  const [payload, setPayload] = useState("")
  const [notes, setNotes] = useState("")

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const fd = new FormData()
    fd.set("league", league)
    fd.set("payload", payload)
    fd.set("notes", notes)
    startTransition(async () => {
      const res = await ingestProps(fd)
      if (!res.ok) {
        toast.error(res.error)
        return
      }
      toast.success(`Ingested ${res.count} props.`)
      setPayload("")
      setNotes("")
      router.push("/")
      router.refresh()
    })
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <FieldGroup>
        <Field>
          <FieldLabel htmlFor="league">League</FieldLabel>
          <Select value={league} onValueChange={(v) => setLeague(v as League)}>
            <SelectTrigger id="league" className="w-full sm:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LEAGUES.map((l) => (
                <SelectItem key={l} value={l} className="font-mono text-xs uppercase tracking-wider">
                  {l}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        <Field>
          <FieldLabel htmlFor="payload">WagerWise Scraper JSON</FieldLabel>
          <Textarea
            id="payload"
            value={payload}
            onChange={(e) => setPayload(e.target.value)}
            placeholder='Paste the WagerWise scraper output here. Run the bookmarklet on PrizePicks or Underdog, then paste the JSON array. Supports fields: player, market, line, projection, hitRate, L5, L10, position, team, opponent, etc.'
            className="min-h-[280px] font-mono text-xs"
            spellCheck={false}
            required
          />
          <p className="mt-1.5 text-xs text-muted-foreground">
            Tip: The scraper extracts hit rates, L5/L10 trends, projections, and player positions automatically.
          </p>
        </Field>

        <Field>
          <FieldLabel htmlFor="notes">
            Notes <span className="text-muted-foreground">(optional)</span>
          </FieldLabel>
          <Input
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. evening slate, 8 games"
          />
        </Field>
      </FieldGroup>

      <div className="flex items-center justify-between">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          {payload.length.toLocaleString()} chars staged
        </p>
        <Button type="submit" disabled={pending} className="font-mono text-xs uppercase tracking-wider">
          {pending ? <Spinner className="mr-2" /> : <Upload className="mr-2 size-3.5" />}
          Ingest
        </Button>
      </div>

      {/* keep refs */}
      <Label className="sr-only">Ingest WagerWise props</Label>
    </form>
  )
}
