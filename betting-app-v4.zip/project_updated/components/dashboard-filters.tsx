"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useTransition } from "react"
import { cn } from "@/lib/utils"
import { LEAGUES, type Tier } from "@/lib/types"

const TIERS: (Tier | "ALL")[] = ["ALL", "LOCK", "VALUE", "RISKY", "PASS"]

export function DashboardFilters({ league, tier }: { league: string; tier: string }) {
  const router = useRouter()
  const params = useSearchParams()
  const [, startTransition] = useTransition()

  function update(key: "league" | "tier", value: string) {
    const next = new URLSearchParams(params.toString())
    if (value === "ALL") next.delete(key)
    else next.set(key, value)
    startTransition(() => {
      router.replace(`/?${next.toString()}`, { scroll: false })
    })
  }

  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="mr-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">League</span>
        {(["ALL", ...LEAGUES] as const).map((l) => (
          <button
            key={l}
            type="button"
            onClick={() => update("league", l)}
            className={cn(
              "rounded-md px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider transition-colors",
              (league === l || (l === "ALL" && !league))
                ? "bg-primary/15 text-primary ring-1 ring-primary/30"
                : "bg-secondary/50 text-muted-foreground hover:text-foreground",
            )}
          >
            {l}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="mr-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Tier</span>
        {TIERS.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => update("tier", t)}
            className={cn(
              "rounded-md px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider transition-colors",
              (tier === t || (t === "ALL" && !tier))
                ? "bg-foreground/10 text-foreground ring-1 ring-border"
                : "bg-secondary/50 text-muted-foreground hover:text-foreground",
            )}
          >
            {t}
          </button>
        ))}
      </div>
    </div>
  )
}
