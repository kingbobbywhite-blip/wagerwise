import { ArrowDown, ArrowUp, Minus } from "lucide-react"
import { cn } from "@/lib/utils"

export function EdgeCell({ edge, recommendation }: { edge: number | null; recommendation: string | null }) {
  if (edge == null) {
    return (
      <span className="inline-flex items-center gap-1 font-mono text-xs text-muted-foreground">
        <Minus className="size-3" aria-hidden />
        --
      </span>
    )
  }
  const positive = recommendation === "OVER"
  const negative = recommendation === "UNDER"
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 font-mono text-xs tabular-nums",
        positive && "text-primary",
        negative && "text-destructive",
        !positive && !negative && "text-muted-foreground",
      )}
    >
      {positive ? <ArrowUp className="size-3" aria-hidden /> : null}
      {negative ? <ArrowDown className="size-3" aria-hidden /> : null}
      {!positive && !negative ? <Minus className="size-3" aria-hidden /> : null}
      {edge > 0 ? "+" : ""}
      {edge.toFixed(1)}%
    </span>
  )
}
