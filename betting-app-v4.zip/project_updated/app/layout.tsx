import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Toaster } from "@/components/ui/sonner"
import { SiteHeader } from "@/components/site-header"
import "./globals.css"

const geist = Geist({ subsets: ["latin"], variable: "--font-geist" })
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" })

export const metadata: Metadata = {
  title: "WagerWise — Prop Terminal",
  description: "Tiered prop slip builder with edge analysis across NBA, WNBA, NFL, and NCAA.",
  generator: "v0.app",
}

export const viewport: Viewport = {
  themeColor: "#0c0f12",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`dark ${geist.variable} ${geistMono.variable}`}>
      <body className="min-h-screen bg-background font-sans text-foreground antialiased">
        <SiteHeader />
        <main className="mx-auto w-full max-w-7xl px-4 py-6 md:px-6 md:py-8">{children}</main>
        <Toaster richColors position="top-right" theme="dark" />
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
