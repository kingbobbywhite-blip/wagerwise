import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { StatCard } from "@/components/stat-card"
import { Button } from "@/components/ui/button"
import { TierBadge } from "@/components/tier-badge"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { History as HistoryIcon, Target, TrendingUp, Trophy, XCircle, DollarSign } from "lucide-react"
import type { Slip, SlipLeg, SlipStatus } from "@/lib/types"
import { SLIP_SELECT } from "@/lib/types"
import { diffLegs, slipProfit } from "@/lib/compare"
import { getSettings } from "@/lib/settings"
import { cn } from "@/lib/utils"

export const dynamic = "force-dynamic"

const STATUS_STYLES: Record<SlipStatus, string> = {
  PENDING: "bg-secondary text-muted-foreground",
  WON: "bg-primary/15 text-primary",
  LOST: "bg-destructive/15 text-destructive",
  PUSH: "bg-muted text-muted-foreground",
  VOID: "bg-muted text-muted-foreground",
}

export default async function HistoryPage() {
  const supabase = await createClient()
  const settings = await getSettings()

  const { data: slipData } = await supabase
    .from("slips")
    .select(SLIP_SELECT)
    .order("created_at", { ascending: false })
    .limit(200)
  const allSlips = (slipData ?? []) as Slip[]
  const playedSlips = allSlips.filter((s) => s.kind === "PLAYED")

  // Hydrate units_played-derived stake when stake is null
  const playedHydrated = playedSlips.map((s) => ({
    ...s,
    stake:
      s.stake != null
        ? Number(s.stake)
        : s.units_played != null
          ? Number(s.units_played) * settings.unit_size
          : null,
  }))

  const settled = playedHydrated.filter((s) => s.status !== "PENDING" && s.status !== "VOID")
  const won = settled.filter((s) => s.status === "WON").length
  const lost = settled.filter((s) => s.status === "LOST").length
  const winRate = settled.length > 0 ? (won / settled.length) * 100 : 0
  const pending = playedHydrated.filter((s) => s.status === "PENDING").length
  const totalProfit = playedHydrated.reduce((acc, s) => acc + slipProfit(s), 0)
  const totalStaked = settled.reduce((acc, s) => acc + (s.stake ?? 0), 0)
  const roi = totalStaked > 0 ? (totalProfit / totalStaked) * 100 : 0

  // Comparison: pull legs for played + their parents to compute deviations
  const ids = playedSlips.map((s) => s.id)
  const parentIds = playedSlips.map((s) => s.parent_slip_id).filter(Boolean) as string[]
  const allIds = [...new Set([...ids, ...parentIds])]
  const { data: legData } = allIds.length
    ? await supabase
        .from("slip_legs")
        .select("id, slip_id, prop_id, player, market, line, pick, odds, result, actual_value, position")
        .in("slip_id", allIds)
        .order("position", { ascending: true })
    : { data: [] }
  const legs = (legData ?? []).map((l) => ({ ...l, line: Number(l.line) })) as SlipLeg[]
  const legsBySlip = new Map<string, SlipLeg[]>()
  for (const l of legs) {
    const list = legsBySlip.get(l.slip_id) ?? []
    list.push(l)
    legsBySlip.set(l.slip_id, list)
  }

  // Deviation analysis on played slips with parents
  const linkedPlayed = playedSlips.filter((s) => s.parent_slip_id)
  let identicalCount = 0
  let deviantCount = 0
  for (const p of linkedPlayed) {
    const pLegs = legsBySlip.get(p.id) ?? []
    const sLegs = legsBySlip.get(p.parent_slip_id!) ?? []
    const diffs = diffLegs(sLegs, pLegs)
    const changes = diffs.filter((d) => d.status !== "kept").length
    if (changes === 0) identicalCount++
    else deviantCount++
  }

  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Performance</p>
          <h1 className="mt-1 font-mono text-2xl font-semibold tracking-tight">History</h1>
        </div>
      </header>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-5">
        <StatCard label="Played slips" value={playedSlips.length} icon={HistoryIcon} />
        <StatCard label="Win rate" value={settled.length > 0 ? `${winRate.toFixed(1)}%` : "--"} icon={Target} tone="primary" />
        <StatCard
          label="Net P/L"
          value={totalStaked > 0 ? `${totalProfit >= 0 ? "+" : ""}$${totalProfit.toFixed(0)}` : "$0"}
          icon={DollarSign}
          tone={totalProfit >= 0 ? "primary" : "destructive"}
        />
        <StatCard
          label="ROI"
          value={totalStaked > 0 ? `${roi >= 0 ? "+" : ""}${roi.toFixed(1)}%` : "--"}
          icon={TrendingUp}
          tone={roi >= 0 ? "primary" : "destructive"}
        />
        <StatCard label={`${won}W · ${lost}L`} value={`${pending} pending`} icon={Trophy} />
      </section>

      {linkedPlayed.length > 0 ? (
        <section className="rounded-lg border border-border/60 bg-card p-5">
          <header className="flex items-baseline justify-between">
            <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.16em]">Discipline check</h2>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              Played slips linked to a suggestion
            </p>
          </header>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Followed</p>
              <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-primary">{identicalCount}</p>
              <p className="font-mono text-[10px] text-muted-foreground">Identical to suggestion</p>
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Deviated</p>
              <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-accent">{deviantCount}</p>
              <p className="font-mono text-[10px] text-muted-foreground">At least one swap/add/remove</p>
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Compliance</p>
              <p className="mt-1 font-mono text-2xl font-semibold tabular-nums">
                {linkedPlayed.length > 0 ? `${Math.round((identicalCount / linkedPlayed.length) * 100)}%` : "--"}
              </p>
              <p className="font-mono text-[10px] text-muted-foreground">Times you trusted the model</p>
            </div>
          </div>
        </section>
      ) : null}

      {playedSlips.length === 0 ? (
        <Empty className="border border-dashed border-border/60 bg-card/40">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <TrendingUp className="size-5" />
            </EmptyMedia>
            <EmptyTitle className="font-mono text-base">No history yet</EmptyTitle>
            <EmptyDescription>Save your first slip to start tracking results.</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button asChild className="font-mono text-xs uppercase tracking-wider">
              <Link href="/">Go to dashboard</Link>
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border/60 bg-card">
          <table className="w-full text-sm">
            <thead className="bg-secondary/40">
              <tr className="border-b border-border/60 text-left font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                <th className="px-3 py-2.5">Date</th>
                <th className="px-3 py-2.5">Slip</th>
                <th className="px-3 py-2.5">Type</th>
                <th className="px-3 py-2.5">League</th>
                <th className="px-3 py-2.5 text-right">Stake</th>
                <th className="px-3 py-2.5 text-right">Odds</th>
                <th className="px-3 py-2.5 text-right">P/L</th>
                <th className="px-3 py-2.5">Status</th>
              </tr>
            </thead>
            <tbody>
              {playedHydrated.map((s) => {
                const pl = slipProfit(s)
                return (
                  <tr key={s.id} className="border-b border-border/40 last:border-0 hover:bg-secondary/30">
                    <td className="px-3 py-2.5 font-mono text-xs text-muted-foreground tabular-nums">
                      {new Date(s.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-3 py-2.5">
                      <Link href={`/slips/${s.id}`} className="font-medium hover:text-primary">
                        {s.name}
                      </Link>
                      {s.parent_slip_id ? (
                        <span className="ml-2 rounded bg-primary/10 px-1 py-0.5 font-mono text-[9px] uppercase tracking-wider text-primary">
                          linked
                        </span>
                      ) : null}
                    </td>
                    <td className="px-3 py-2.5">
                      <TierBadge
                        tier={s.slip_type === "SAFE" ? "LOCK" : s.slip_type === "VALUE" ? "VALUE" : "RISKY"}
                      />
                    </td>
                    <td className="px-3 py-2.5 font-mono text-xs text-muted-foreground">{s.league ?? "—"}</td>
                    <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums">
                      {s.stake != null ? `$${Number(s.stake).toFixed(0)}` : "--"}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-xs tabular-nums">
                      {s.payout_odds == null ? "--" : s.payout_odds > 0 ? `+${s.payout_odds}` : s.payout_odds}
                    </td>
                    <td
                      className={cn(
                        "px-3 py-2.5 text-right font-mono text-xs font-semibold tabular-nums",
                        pl > 0 && "text-primary",
                        pl < 0 && "text-destructive",
                      )}
                    >
                      {pl === 0 && s.status === "PENDING" ? "--" : `${pl >= 0 ? "+" : ""}$${pl.toFixed(0)}`}
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className={cn(
                          "rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]",
                          STATUS_STYLES[s.status],
                        )}
                      >
                        {s.status}
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
