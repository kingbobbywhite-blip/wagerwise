import { SettingsForm } from "@/components/settings-form"
import { getSettings } from "@/lib/settings"

export const dynamic = "force-dynamic"

export default async function SettingsPage() {
  const settings = await getSettings()

  return (
    <div className="max-w-xl space-y-6">
      <header>
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Bankroll</p>
        <h1 className="mt-1 font-mono text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          These values drive recommended stake sizing on suggested slips. Quarter-Kelly is the default — a conservative
          position-sizer that survives variance and bad estimates.
        </p>
      </header>

      <SettingsForm initial={settings} />
    </div>
  )
}
