"use server"

import { revalidatePath } from "next/cache"
import { createClient } from "@/lib/supabase/server"

export async function updateSettings(input: {
  bankroll: number
  unit_size: number
  kelly_fraction: number
}) {
  const supabase = await createClient()
  const { error } = await supabase
    .from("settings")
    .update({
      bankroll: input.bankroll,
      unit_size: input.unit_size,
      kelly_fraction: input.kelly_fraction,
      updated_at: new Date().toISOString(),
    })
    .eq("id", 1)

  if (error) return { ok: false as const, error: error.message }
  revalidatePath("/")
  revalidatePath("/settings")
  return { ok: true as const }
}
