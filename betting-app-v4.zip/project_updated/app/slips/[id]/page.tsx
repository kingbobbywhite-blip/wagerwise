import Link from "next/link"
import { notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { formatAmerican } from "@/lib/odds"
import { formatDistanceToNow } from "date-fns"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"
import type { Slip, SlipLeg } from "@/lib/types"
import { SLIP_SELECT } from "@/lib/types"
import { SlipDetailControls } from "@/components/slip-detail-controls"
import { SlipComparison } from "@/components/slip-comparison"
import { cn } from "@/lib/utils"

export const dynamic = "force-dynamic"

export default async function SlipDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()
  const { data: slipData } = await supabase.from("slips").select(SLIP_SELECT).eq("id", id).maybeSingle()

  if (!slipData) notFound()
  const slip = slipData as Slip

  const { data: legData } = await supabase
    .from("slip_legs")
    .select("id, slip_id, prop_id, player, market, line, pick, odds, result, actual_value, position")
    .eq("slip_id", id)
    .order("position", { ascending: true })
  const legs = (legData ?? []).map((l) => ({ ...l, line: Number(l.line) })) as SlipLeg[]

  // If this is PLAYED with a parent, fetch the suggestion + its legs for comparison
  let parentSlip: Slip | null = null
  let parentLegs: SlipLeg[] = []
  if (slip.kind === "PLAYED" && slip.parent_slip_id) {
    const { data: pSlip } = await supabase
      .from("slips")
      .select(SLIP_SELECT)
      .eq("id", slip.parent_slip_id)
      .maybeSingle()
    if (pSlip) parentSlip = pSlip as Slip
    const { data: pLegs } = await supabase
      .from("slip_legs")
      .select("id, slip_id, prop_id, player, market, line, pick, odds, result, actual_value, position")
      .eq("slip_id", slip.parent_slip_id)
      .order("position", { ascending: true })
    parentLegs = (pLegs ?? []).map((l) => ({ ...l, line: Number(l.line) })) as SlipLeg[]
  }

  return (
    <div className="space-y-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="font-mono text-[11px] uppercase tracking-wider">
          <Link href="/slips">
            <ChevronLeft className="mr-1 size-3.5" />
            Back to slips
          </Link>
        </Button>
      </div>

      <header className="rounded-lg border border-border/60 bg-card p-5">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em]",
              slip.kind === "PLAYED" ? "bg-accent/15 text-accent" : "bg-primary/15 text-primary",
            )}
          >
            {slip.kind}
          </span>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {slip.slip_type} · {slip.league ?? "Mixed"} ·{" "}
            {formatDistanceToNow(new Date(slip.created_at), { addSuffix: true })}
          </p>
        </div>
        <h1 className="mt-2 font-mono text-2xl font-semibold tracking-tight">{slip.name}</h1>
        <div className="mt-3 flex flex-wrap items-baseline gap-x-6 gap-y-2">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Payout odds</p>
            <p className="font-mono text-2xl font-semibold tabular-nums text-primary">
              {formatAmerican(slip.payout_odds)}
            </p>
          </div>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Legs</p>
            <p className="font-mono text-2xl font-semibold tabular-nums">{legs.length}</p>
          </div>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Status</p>
            <p className="font-mono text-2xl font-semibold tracking-tight">{slip.status}</p>
          </div>
          {slip.units_played != null ? (
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Units</p>
              <p className="font-mono text-2xl font-semibold tabular-nums">{Number(slip.units_played).toFixed(2)}</p>
            </div>
          ) : null}
        </div>
      </header>

      {parentSlip ? <SlipComparison played={slip} playedLegs={legs} suggested={parentSlip} suggestedLegs={parentLegs} /> : null}

      <SlipDetailControls slip={slip} legs={legs} />
    </div>
  )
}
