import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { formatAmerican } from "@/lib/odds"
import { formatDistanceToNow } from "date-fns"
import { TierBadge } from "@/components/tier-badge"
import { Button } from "@/components/ui/button"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { ChevronRight, Receipt } from "lucide-react"
import type { Slip, SlipLeg, SlipStatus } from "@/lib/types"
import { SLIP_SELECT } from "@/lib/types"
import { cn } from "@/lib/utils"

export const dynamic = "force-dynamic"

const STATUS_STYLES: Record<SlipStatus, string> = {
  PENDING: "bg-secondary text-muted-foreground ring-border",
  WON: "bg-primary/15 text-primary ring-primary/30",
  LOST: "bg-destructive/15 text-destructive ring-destructive/30",
  PUSH: "bg-muted text-muted-foreground ring-border",
  VOID: "bg-muted text-muted-foreground ring-border",
}

export default async function SlipsPage({
  searchParams,
}: {
  searchParams: Promise<{ kind?: string }>
}) {
  const { kind = "" } = await searchParams
  const supabase = await createClient()
  let query = supabase.from("slips").select(SLIP_SELECT).order("created_at", { ascending: false }).limit(50)
  if (kind === "SUGGESTED" || kind === "PLAYED") query = query.eq("kind", kind)

  const { data: slipData } = await query
  const slips = (slipData ?? []) as Slip[]

  const { data: legData } = await supabase
    .from("slip_legs")
    .select("id, slip_id, prop_id, player, market, line, pick, odds, result, actual_value, position")
    .in("slip_id", slips.map((s) => s.id))
    .order("position", { ascending: true })
  const legs = (legData ?? []).map((l) => ({ ...l, line: Number(l.line) })) as SlipLeg[]
  const legsBySlip = new Map<string, SlipLeg[]>()
  for (const l of legs) {
    const list = legsBySlip.get(l.slip_id) ?? []
    list.push(l)
    legsBySlip.set(l.slip_id, list)
  }

  const tabs: { value: string; label: string }[] = [
    { value: "", label: "All" },
    { value: "PLAYED", label: "Played" },
    { value: "SUGGESTED", label: "Suggested" },
  ]

  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Saved slips</p>
          <h1 className="mt-1 font-mono text-2xl font-semibold tracking-tight">Slips</h1>
        </div>
        <nav className="flex items-center gap-1">
          {tabs.map((t) => {
            const active = kind === t.value
            return (
              <Link
                key={t.value || "all"}
                href={t.value ? `/slips?kind=${t.value}` : "/slips"}
                className={cn(
                  "rounded-md px-3 py-1.5 font-mono text-[11px] uppercase tracking-wider transition-colors",
                  active
                    ? "bg-primary/15 text-primary ring-1 ring-primary/30"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                )}
              >
                {t.label}
              </Link>
            )
          })}
        </nav>
      </header>

      {slips.length === 0 ? (
        <Empty className="border border-dashed border-border/60 bg-card/40">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Receipt className="size-5" />
            </EmptyMedia>
            <EmptyTitle className="font-mono text-base">No slips saved</EmptyTitle>
            <EmptyDescription>Build a slip from the dashboard to track results here.</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button asChild className="font-mono text-xs uppercase tracking-wider">
              <Link href="/">Go to dashboard</Link>
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {slips.map((s) => {
            const slipLegs = legsBySlip.get(s.id) ?? []
            return (
              <li key={s.id}>
                <Link
                  href={`/slips/${s.id}`}
                  className="group block h-full rounded-lg border border-border/60 bg-card p-4 transition-colors hover:border-border"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TierBadge tier={s.slip_type === "SAFE" ? "LOCK" : s.slip_type === "VALUE" ? "VALUE" : "RISKY"} />
                      <span
                        className={cn(
                          "rounded px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.14em]",
                          s.kind === "PLAYED" ? "bg-accent/15 text-accent" : "bg-primary/15 text-primary",
                        )}
                      >
                        {s.kind}
                      </span>
                      <span
                        className={cn(
                          "rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] ring-1",
                          STATUS_STYLES[s.status],
                        )}
                      >
                        {s.status}
                      </span>
                    </div>
                    <ChevronRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
                  </div>
                  <h3 className="mt-2 font-mono text-sm font-semibold tracking-tight">{s.name}</h3>
                  <div className="mt-1 flex items-baseline gap-2">
                    <span className="font-mono text-xl font-semibold tabular-nums text-primary">
                      {formatAmerican(s.payout_odds)}
                    </span>
                    <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                      {slipLegs.length} legs · {s.league ?? "—"}
                      {s.units_played != null ? ` · ${Number(s.units_played).toFixed(1)}u` : ""}
                    </span>
                  </div>
                  <ul className="mt-3 space-y-1">
                    {slipLegs.slice(0, 3).map((l) => (
                      <li key={l.id} className="flex items-center justify-between gap-2 font-mono text-[11px]">
                        <span className="truncate">
                          <span className="text-muted-foreground">{l.pick}</span>{" "}
                          <span className="text-foreground">{l.player}</span>
                          <span className="text-muted-foreground">
                            {" "}
                            · {l.market} {Number(l.line)}
                          </span>
                        </span>
                        <span
                          className={cn(
                            "shrink-0 rounded px-1 py-0.5 text-[9px] font-semibold uppercase tracking-wider",
                            l.result === "WIN" && "bg-primary/15 text-primary",
                            l.result === "LOSS" && "bg-destructive/15 text-destructive",
                            l.result === "PENDING" && "text-muted-foreground",
                            (l.result === "PUSH" || l.result === "VOID") && "text-muted-foreground",
                          )}
                        >
                          {l.result}
                        </span>
                      </li>
                    ))}
                    {slipLegs.length > 3 ? (
                      <li className="font-mono text-[10px] text-muted-foreground">+{slipLegs.length - 3} more</li>
                    ) : null}
                  </ul>
                  <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    {formatDistanceToNow(new Date(s.created_at), { addSuffix: true })}
                  </p>
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
