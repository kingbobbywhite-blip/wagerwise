"use server"

import { revalidatePath } from "next/cache"
import { createClient } from "@/lib/supabase/server"
import { parlayOdds } from "@/lib/odds"
import type { LegResult, Pick, SlipKind, SlipStatus, SlipType } from "@/lib/types"

interface SlipLegInput {
  prop_id: string | null
  player: string
  market: string
  line: number
  pick: Pick
  odds: number | null
}

export type CreateSlipResult =
  | { ok: true; slipId: string }
  | { ok: false; error: string }

export async function createSlip(input: {
  name: string
  league: string | null
  slipType: SlipType
  kind?: SlipKind
  parentSlipId?: string | null
  recommendedUnits?: number | null
  unitsPlayed?: number | null
  legs: SlipLegInput[]
  notes?: string | null
  stake?: number | null
}): Promise<CreateSlipResult> {
  if (input.legs.length === 0) {
    return { ok: false, error: "A slip needs at least one leg." }
  }
  const oddsList = input.legs.map((l) => l.odds ?? -110)
  const payoutOdds = parlayOdds(oddsList)

  const supabase = await createClient()
  const { data: slip, error } = await supabase
    .from("slips")
    .insert({
      name: input.name,
      league: input.league,
      slip_type: input.slipType,
      kind: input.kind ?? "SUGGESTED",
      parent_slip_id: input.parentSlipId ?? null,
      payout_odds: payoutOdds,
      stake: input.stake ?? null,
      recommended_units: input.recommendedUnits ?? null,
      units_played: input.unitsPlayed ?? null,
      notes: input.notes ?? null,
    })
    .select("id")
    .single()

  if (error || !slip) return { ok: false, error: error?.message ?? "Failed to create slip." }

  const legRows = input.legs.map((l, idx) => ({
    slip_id: slip.id,
    prop_id: l.prop_id,
    player: l.player,
    market: l.market,
    line: l.line,
    pick: l.pick,
    odds: l.odds,
    position: idx,
  }))
  const { error: legErr } = await supabase.from("slip_legs").insert(legRows)
  if (legErr) {
    await supabase.from("slips").delete().eq("id", slip.id)
    return { ok: false, error: legErr.message }
  }

  revalidatePath("/slips")
  revalidatePath("/history")
  revalidatePath("/")
  return { ok: true, slipId: slip.id }
}

/**
 * Clone an existing SUGGESTED slip into a PLAYED child the user can then edit.
 * Copies all legs, sets units_played = recommended_units initially.
 */
export async function cloneSuggestedAsPlayed(slipId: string): Promise<CreateSlipResult> {
  const supabase = await createClient()
  const { data: parent } = await supabase
    .from("slips")
    .select("id, name, league, slip_type, kind, payout_odds, recommended_units, notes")
    .eq("id", slipId)
    .maybeSingle()
  if (!parent) return { ok: false, error: "Suggested slip not found." }
  if (parent.kind !== "SUGGESTED") return { ok: false, error: "Only SUGGESTED slips can be cloned." }

  const { data: legs } = await supabase
    .from("slip_legs")
    .select("prop_id, player, market, line, pick, odds, position")
    .eq("slip_id", slipId)
    .order("position", { ascending: true })

  if (!legs || legs.length === 0) return { ok: false, error: "Suggested slip has no legs." }

  const stake = parent.recommended_units != null ? null : null

  const { data: child, error } = await supabase
    .from("slips")
    .insert({
      name: `${parent.name} (played)`,
      league: parent.league,
      slip_type: parent.slip_type,
      kind: "PLAYED",
      parent_slip_id: parent.id,
      payout_odds: parent.payout_odds,
      stake,
      recommended_units: parent.recommended_units,
      units_played: parent.recommended_units,
      notes: parent.notes,
    })
    .select("id")
    .single()

  if (error || !child) return { ok: false, error: error?.message ?? "Failed to clone slip." }

  const legRows = legs.map((l, idx) => ({
    slip_id: child.id,
    prop_id: l.prop_id,
    player: l.player,
    market: l.market,
    line: Number(l.line),
    pick: l.pick,
    odds: l.odds,
    position: idx,
  }))
  const { error: legErr } = await supabase.from("slip_legs").insert(legRows)
  if (legErr) {
    await supabase.from("slips").delete().eq("id", child.id)
    return { ok: false, error: legErr.message }
  }

  revalidatePath("/slips")
  revalidatePath("/history")
  revalidatePath(`/slips/${slipId}`)
  return { ok: true, slipId: child.id }
}

export async function updateSlipStatus(slipId: string, status: SlipStatus) {
  const supabase = await createClient()
  await supabase
    .from("slips")
    .update({ status, settled_at: status === "PENDING" ? null : new Date().toISOString() })
    .eq("id", slipId)
  revalidatePath("/slips")
  revalidatePath("/history")
  revalidatePath(`/slips/${slipId}`)
}

export async function updateLegResult(legId: string, slipId: string, result: LegResult, actual?: number | null) {
  const supabase = await createClient()
  await supabase
    .from("slip_legs")
    .update({ result, actual_value: actual ?? null })
    .eq("id", legId)
  revalidatePath(`/slips/${slipId}`)
  revalidatePath("/history")
}

export async function togglePick(legId: string, slipId: string, currentPick: Pick) {
  const supabase = await createClient()
  const next: Pick = currentPick === "OVER" ? "UNDER" : "OVER"
  await supabase.from("slip_legs").update({ pick: next }).eq("id", legId)
  await recalcPayoutOdds(slipId)
  revalidatePath(`/slips/${slipId}`)
}

export async function removeLeg(legId: string, slipId: string) {
  const supabase = await createClient()
  await supabase.from("slip_legs").delete().eq("id", legId)
  await recalcPayoutOdds(slipId)
  revalidatePath(`/slips/${slipId}`)
  revalidatePath("/history")
}

export async function updateSlipUnitsPlayed(slipId: string, units: number | null) {
  const supabase = await createClient()
  await supabase.from("slips").update({ units_played: units }).eq("id", slipId)
  revalidatePath(`/slips/${slipId}`)
  revalidatePath("/history")
}

export async function updateSlipNotes(slipId: string, notes: string) {
  const supabase = await createClient()
  await supabase.from("slips").update({ notes }).eq("id", slipId)
  revalidatePath(`/slips/${slipId}`)
}

export async function deleteSlip(slipId: string) {
  const supabase = await createClient()
  await supabase.from("slips").delete().eq("id", slipId)
  revalidatePath("/slips")
  revalidatePath("/history")
}

async function recalcPayoutOdds(slipId: string) {
  const supabase = await createClient()
  const { data } = await supabase.from("slip_legs").select("odds").eq("slip_id", slipId)
  const oddsList = (data ?? []).map((l) => Number(l.odds ?? -110))
  if (oddsList.length === 0) {
    await supabase.from("slips").update({ payout_odds: null }).eq("id", slipId)
    return
  }
  const payout = parlayOdds(oddsList)
  await supabase.from("slips").update({ payout_odds: payout }).eq("id", slipId)
}
