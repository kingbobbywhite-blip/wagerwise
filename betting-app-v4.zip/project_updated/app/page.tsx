import Link from "next/link"
import { Button } from "@/components/ui/button"
import { StatCard } from "@/components/stat-card"
import { DashboardFilters } from "@/components/dashboard-filters"
import { PropTable } from "@/components/prop-table"
import { SuggestedSlipCard } from "@/components/suggested-slip-card"
import { createClient } from "@/lib/supabase/server"
import { buildSuggestedSlips } from "@/lib/slip-builder"
import { getSettings } from "@/lib/settings"
import type { Prop, Tier } from "@/lib/types"
import { ArrowUpRight, Flame, Target, Sparkles, Layers } from "lucide-react"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"

export const dynamic = "force-dynamic"

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ league?: string; tier?: string }>
}) {
  const { league = "", tier = "" } = await searchParams
  const supabase = await createClient()
  const settings = await getSettings()

  const { data: lastIngest } = await supabase
    .from("ingests")
    .select("id, league, created_at")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle()

  let query = supabase
    .from("props")
    .select(
      "id, ingest_id, league, player, team, opponent, game_time, market, line, over_odds, under_odds, projection, edge_pct, recommendation, tier, confidence, raw, created_at",
    )
    .order("created_at", { ascending: false })
    .limit(500)

  if (lastIngest?.id) {
    query = query.eq("ingest_id", lastIngest.id)
  }

  const { data: propsData } = await query
  const allProps = ((propsData ?? []) as Prop[]).map((p) => ({
    ...p,
    line: Number(p.line),
    projection: p.projection != null ? Number(p.projection) : null,
    edge_pct: p.edge_pct != null ? Number(p.edge_pct) : null,
    confidence: p.confidence != null ? Number(p.confidence) : null,
  }))

  const filtered = allProps.filter((p) => {
    if (league && p.league !== league) return false
    if (tier && p.tier !== (tier as Tier)) return false
    return true
  })

  const total = filtered.length
  const lockCount = filtered.filter((p) => p.tier === "LOCK").length
  const valueCount = filtered.filter((p) => p.tier === "VALUE").length
  const edgeProps = filtered.filter((p) => p.edge_pct != null && p.tier !== "PASS")
  const avgEdge =
    edgeProps.length > 0 ? edgeProps.reduce((acc, p) => acc + Math.abs(p.edge_pct ?? 0), 0) / edgeProps.length : 0

  const suggested = buildSuggestedSlips(filtered, settings)
  const slipLeague = league || lastIngest?.league || null

  const tierRank: Record<string, number> = { LOCK: 0, VALUE: 1, RISKY: 2, PASS: 3 }
  const sorted = [...filtered].sort((a, b) => {
    const ar = tierRank[a.tier ?? "PASS"] ?? 9
    const br = tierRank[b.tier ?? "PASS"] ?? 9
    if (ar !== br) return ar - br
    return Math.abs(b.edge_pct ?? 0) - Math.abs(a.edge_pct ?? 0)
  })

  return (
    <div className="space-y-8">
      <header className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {lastIngest
              ? `Latest ingest · ${lastIngest.league} · ${new Date(lastIngest.created_at).toLocaleString()}`
              : "No ingests yet"}
          </p>
          <h1 className="mt-1 font-mono text-2xl font-semibold tracking-tight md:text-3xl">Today&apos;s board</h1>
          <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            Bankroll ${settings.bankroll.toLocaleString()} · 1u = ${settings.unit_size} ·{" "}
            {(settings.kelly_fraction * 100).toFixed(0)}% Kelly
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="secondary" className="font-mono text-xs uppercase tracking-wider">
            <Link href="/slips">
              View slips
              <ArrowUpRight className="ml-1.5 size-3.5" />
            </Link>
          </Button>
          <Button asChild className="font-mono text-xs uppercase tracking-wider">
            <Link href="/ingest">New ingest</Link>
          </Button>
        </div>
      </header>

      {allProps.length === 0 ? (
        <Empty className="border border-dashed border-border/60 bg-card/40">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Sparkles className="size-5" />
            </EmptyMedia>
            <EmptyTitle className="font-mono text-base">No props loaded</EmptyTitle>
            <EmptyDescription>
              Paste your WagerWise scraper output to see edges, tiers, and auto-built slips.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button asChild className="font-mono text-xs uppercase tracking-wider">
              <Link href="/ingest">Ingest props</Link>
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <>
          <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard label="Props in pool" value={total} icon={Layers} />
            <StatCard label="Locks" value={lockCount} icon={Target} tone="primary" />
            <StatCard label="Value plays" value={valueCount} icon={Sparkles} tone="accent" />
            <StatCard
              label="Avg |edge|"
              value={Number.isFinite(avgEdge) ? `${avgEdge.toFixed(1)}%` : "--"}
              icon={Flame}
              hint="Excludes PASS-tier props"
            />
          </section>

          {suggested.length > 0 ? (
            <section>
              <header className="mb-3 flex items-baseline justify-between">
                <div>
                  <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.16em] text-foreground">
                    Profit-optimized parlays
                  </h2>
                  <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground mt-0.5">
                    Cross-market · best prob × payout · {suggested.length} slips
                  </p>
                </div>
                <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  {(settings.kelly_fraction * 100).toFixed(0)}% Kelly · 10% bankroll cap
                </p>
              </header>
              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                {suggested.map((s) => (
                  <SuggestedSlipCard
                    key={s.name}
                    type={s.type}
                    name={s.name}
                    legs={s.legs}
                    payoutOdds={s.payoutOdds}
                    rationale={s.rationale}
                    league={slipLeague}
                    winProb={s.winProb}
                    recommendedStake={s.recommendedStake}
                    recommendedUnits={s.recommendedUnits}
                    unitSize={settings.unit_size}
                  />
                ))}
              </div>
            </section>
          ) : null}

          <section className="space-y-3">
            <header className="flex items-baseline justify-between">
              <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.16em] text-foreground">Prop board</h2>
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                {sorted.length.toLocaleString()} shown
              </p>
            </header>
            <DashboardFilters league={league} tier={tier} />
            <PropTable props={sorted} emptyLabel="No props match the current filters." />
          </section>
        </>
      )}
    </div>
  )
}
