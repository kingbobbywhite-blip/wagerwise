import { IngestForm } from "@/components/ingest-form"
import { createClient } from "@/lib/supabase/server"
import { formatDistanceToNow } from "date-fns"
import { Database } from "lucide-react"
import type { Ingest } from "@/lib/types"

export default async function IngestPage() {
  const supabase = await createClient()
  const { data } = await supabase
    .from("ingests")
    .select("id, league, source, prop_count, notes, created_at")
    .order("created_at", { ascending: false })
    .limit(10)
  const ingests = (data ?? []) as Ingest[]

  return (
    <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
      <section>
        <header className="mb-5">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Step 01 — Data In
          </p>
          <h1 className="mt-1 font-mono text-2xl font-semibold tracking-tight">Ingest props</h1>
          <p className="mt-2 max-w-prose text-sm text-muted-foreground">
            Paste the JSON output from your WagerWise scraper bookmarklet. The parser extracts player props including
            hit rates, L5/L10 trends, projections, and positions. Edge is computed automatically and tiers are assigned
            based on value.
          </p>
        </header>
        <div className="rounded-lg border border-border/60 bg-card p-5">
          <IngestForm />
        </div>
      </section>

      <aside className="space-y-3">
        <header>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Recent batches</p>
        </header>
        {ingests.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border/60 bg-card/40 p-6 text-center">
            <Database className="mx-auto size-5 text-muted-foreground" aria-hidden />
            <p className="mt-2 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">No ingests yet</p>
          </div>
        ) : (
          <ul className="space-y-2">
            {ingests.map((i) => (
              <li
                key={i.id}
                className="rounded-lg border border-border/60 bg-card p-3"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-primary">
                    {i.league}
                  </span>
                  <span className="font-mono text-[10px] text-muted-foreground">
                    {formatDistanceToNow(new Date(i.created_at), { addSuffix: true })}
                  </span>
                </div>
                <div className="mt-1.5 flex items-baseline gap-2">
                  <span className="font-mono text-lg font-semibold tabular-nums">{i.prop_count}</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">props</span>
                </div>
                {i.notes ? <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{i.notes}</p> : null}
              </li>
            ))}
          </ul>
        )}
      </aside>
    </div>
  )
}
