"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { parsePropsPayload } from "@/lib/parser"
import { LEAGUES, type League } from "@/lib/types"

export type IngestResult =
  | { ok: true; ingestId: string; count: number }
  | { ok: false; error: string }

export async function ingestProps(formData: FormData): Promise<IngestResult> {
  const leagueRaw = String(formData.get("league") ?? "")
  const notes = String(formData.get("notes") ?? "").trim() || null
  const payload = String(formData.get("payload") ?? "").trim()

  if (!LEAGUES.includes(leagueRaw as League)) {
    return { ok: false, error: "Invalid league." }
  }
  if (!payload) {
    return { ok: false, error: "Paste the scraper JSON before submitting." }
  }

  let parsedJson: unknown
  try {
    parsedJson = JSON.parse(payload)
  } catch {
    return { ok: false, error: "Payload is not valid JSON." }
  }

  const props = parsePropsPayload(parsedJson)
  if (props.length === 0) {
    return { ok: false, error: "No props could be parsed from the payload." }
  }

  const supabase = await createClient()

  const { data: ingest, error: ingestErr } = await supabase
    .from("ingests")
    .insert({
      league: leagueRaw,
      source: "wagerwise",
      raw_json: parsedJson,
      prop_count: props.length,
      notes,
    })
    .select("id")
    .single()

  if (ingestErr || !ingest) {
    return { ok: false, error: ingestErr?.message ?? "Failed to save ingest." }
  }

  const rows = props.map((p) => ({
    ingest_id: ingest.id,
    league: leagueRaw,
    player: p.player,
    team: p.team,
    opponent: p.opponent,
    game_time: p.game_time,
    market: p.market,
    line: p.line,
    over_odds: p.over_odds,
    under_odds: p.under_odds,
    projection: p.projection,
    edge_pct: p.edge_pct,
    recommendation: p.recommendation,
    tier: p.tier,
    confidence: p.confidence,
    raw: p.raw as object,
    // WagerWise scraper fields
    position: p.position,
    hit_rate: p.hit_rate,
    l5: p.l5,
    l10: p.l10,
    source: p.source,
    scraped_at: p.scraped_at,
  }))

  const { error: propErr } = await supabase.from("props").insert(rows)
  if (propErr) {
    return { ok: false, error: propErr.message }
  }

  revalidatePath("/")
  revalidatePath("/ingest")
  return { ok: true, ingestId: ingest.id, count: props.length }
}

export async function clearIngest(ingestId: string) {
  const supabase = await createClient()
  await supabase.from("ingests").delete().eq("id", ingestId)
  revalidatePath("/")
  revalidatePath("/ingest")
  redirect("/ingest")
}
